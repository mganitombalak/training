export interface IProfileProp {
    loggedUserId: number;
    loggedUserName: string;

}