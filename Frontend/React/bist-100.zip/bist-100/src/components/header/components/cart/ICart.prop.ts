export interface ICartProp{
    cartCount:number;
    cartTotal:number;
}