export interface ICarouselProp{
    UserName:string;
}