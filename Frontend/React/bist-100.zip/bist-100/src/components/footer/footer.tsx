import React from 'react';
import './footer.css'
class Footer extends React.Component {
    render = () => (
        <div className="ui segment">
            <p>THIS IS FOOTER</p>
        </div>
    );
}

export default Footer;