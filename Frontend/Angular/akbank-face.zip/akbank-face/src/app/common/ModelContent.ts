import { Type } from '@angular/core';

export class ModalContent {
    constructor(public componentType: Type<any>, public data: any) { }
}
