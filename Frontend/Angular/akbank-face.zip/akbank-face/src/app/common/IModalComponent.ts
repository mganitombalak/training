export interface IModalComponent {
    Bind(data: any);
}