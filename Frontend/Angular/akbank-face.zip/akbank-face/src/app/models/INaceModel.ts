export interface INaceModel {
    code: string;
    description: string;
}
