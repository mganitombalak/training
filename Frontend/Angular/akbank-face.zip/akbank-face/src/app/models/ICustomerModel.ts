export interface ICustomerModel {
    name: string;
    title: string;
    address: string;
}
