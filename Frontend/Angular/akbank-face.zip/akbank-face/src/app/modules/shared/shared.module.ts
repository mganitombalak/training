import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalComponent } from './components/modal/modal.component';
import { ModalContentHostDirective } from 'src/app/common/directive/ModalContentHost.directive';

@NgModule({
  declarations: [ModalComponent, ModalContentHostDirective],
  imports: [
    CommonModule
  ],
  exports: [ModalComponent, ModalContentHostDirective]
})
export class SharedModule { }
