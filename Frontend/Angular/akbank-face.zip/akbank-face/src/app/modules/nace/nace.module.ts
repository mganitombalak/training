import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NaceRoutingModule } from './nace-routing.module';
import { NaceListComponent } from './components/nace-list/nace-list.component';
import { NaceService } from './services/nace.service';

@NgModule({
  declarations: [NaceListComponent],
  imports: [
    CommonModule,
    NaceRoutingModule
  ],
  providers: [NaceService]
})
export class NaceModule { }
