import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-with-problems',
  templateUrl: './payment-with-problems.component.html',
  styleUrls: ['./payment-with-problems.component.css']
})
export class PaymentWithProblemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
