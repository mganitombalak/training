import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awaiting-payment',
  templateUrl: './awaiting-payment.component.html',
  styleUrls: ['./awaiting-payment.component.css']
})
export class AwaitingPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
