import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nopayment',
  templateUrl: './nopayment.component.html',
  styleUrls: ['./nopayment.component.css']
})
export class NopaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
